// src/App.jsx
import { Routes, Route } from "react-router-dom"
import Navbar from "./components/layout/Navbar"
import Home from "./pages/Home/Home"
import Filter from "./pages/Home/Filter"
import Footer from "./components/layout/Footer"

function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />   {/* homepage */}
      </Routes>
      <Footer />

    </>
  )
}

export default App
