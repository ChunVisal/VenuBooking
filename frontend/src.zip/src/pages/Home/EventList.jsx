import { useState } from "react";
import EventCard from "../../components/events/EventCard";
import { EVENTS } from "../../components/data/dataEvent";

const EventList = () => {
  const [filter, setFilter] = useState("All");

  const filteredEvents =
    filter === "All" ? EVENTS : EVENTS.filter((e) => e.category === filter);

  return (
    <section className="">
      <div className="mx-auto max-w-full">
        {/* Header */}
        <div className="flex justify-between p-7 items-center border-b border-gray-300 pb-3 mb-6">
          <h2 className="font-bold text-xl text-gray-800">
            Featured Categories & Events
          </h2>
          {/* grid 3 col */}
          <div className="space-x-4">
            {["All", "Today", "This Week"].map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`pb-1 ${
                  filter === f
                    ? "text-orange-600 border-b-2 border-orange-500"
                    : "text-gray-500 hover:text-gray-700"
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>
        <section className="w-full">
          <div className="grid gap-5 auto-rows-fr 
                          grid-cols-2    /* default (mobile) */
                          sm:grid-cols-2 /* still 2 on small screens */
                          md:grid-cols-3 /* medium screens = 3 */
                          xl:grid-cols-4 /* big/zoomed out = 4 */
                          mx-4 sm:mx-7">
            {filteredEvents.map((event) => (
              <div key={event.id}>
                <EventCard event={event} className="h-full" />
              </div>
            ))}
          </div>
        </section>
      </div>
    </section>
  );
};

export default EventList;
