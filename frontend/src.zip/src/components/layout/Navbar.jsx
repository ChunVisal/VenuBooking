import React, { useState } from 'react';
import { Search, Bell, User, Calendar, Plus, BookOpen, Menu, X } from 'lucide-react';

const Navbar = () => {
  // State to control the visibility of the collapsed mobile menu/links
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Reusable classes for desktop navigation links
  const desktopNavButtonClasses = "flex items-center space-x-1 text-sm text-gray-800 hover:text-orange-500 transition-colors py-2 px-3 rounded-md";

  return (
    <nav className="bg-white border-b border-gray-100 px-4 sm:px-7 py-3 top-0 sticky z-50 shadow-sm">
      <div className="flex items-center justify-between">
        
        {/* Logo/Brand - Always Visible */}
        <div className="flex items-center space-x-1">
          <Calendar className="w-6 h-6 text-orange-500" />
          <h2 className="text-xl font-semibold text-gray-900">VenuBooking</h2>
        </div>

        {/* --- DESKTOP: Full Navigation and Search/Icons --- */}
        <div className="hidden md:flex items-center space-x-6">
            
          {/* Main Navigation Items (Desktop) */}
          <div className="flex items-center space-x-2"> 
            <button className={desktopNavButtonClasses}>
              <Plus className="w-4 h-4" />
              <span>Create</span>
            </button>
            <button className={desktopNavButtonClasses}>
              <Calendar className="w-4 h-4" />
              <span>Events</span>
            </button>
            <button className={desktopNavButtonClasses}>
              <BookOpen className="w-4 h-4" />
              <span>Bookings</span>
            </button>
          </div>

          {/* Desktop Search Bar */}
          <div className="flex items-center space-x-2 bg-gray-100 border border-gray-300 rounded-lg px-3 py-1.5 focus-within:ring-2 focus-within:ring-orange-200">
            <Search className="w-4 h-4 text-gray-600" />
            <input 
              type="text" 
              placeholder="Search venues, events..."
              className="text-sm bg-transparent placeholder-gray-500 outline-none w-48 lg:w-60"
            />
          </div>
          
          {/* Desktop Icons */}
          <button className="text-gray-800 hover:text-orange-500 transition-colors">
            <Bell className="w-5 h-5" />
          </button>
          <button className="text-gray-800 hover:text-orange-500 transition-colors flex items-center space-x-1"> 
            <User className="w-5 h-5" />
            <span className='text-sm'>Account</span>
          </button>
        </div>
        
        {/* --- MOBILE: Icons & Menu Toggle --- */}
        <div className="flex items-center space-x-3 md:hidden">
            {/* Simple Search Icon (Tapping this could open a full-screen search or a dedicated search page) */}
            <button className="text-gray-800 hover:text-orange-500 transition-colors">
                <Search className="w-5 h-5" />
            </button>
            <button className="text-gray-800 hover:text-orange-500 transition-colors">
                <Bell className="w-5 h-5" />
            </button>

            {/* Hamburger/Close Toggle Button */}
            <button 
                className="text-gray-800 hover:text-orange-500 transition-colors ml-2"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
                {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
        </div>
      </div>
      
      {/* --- COLLAPSED MOBILE MENU (Only visible when isMenuOpen is true and on mobile) --- */}
      {isMenuOpen && (
        <div className="md:hidden pt-4 pb-2 border-t border-gray-100 mt-3">
            {/* Mobile Nav Links - Vertically stacked */}
            <div className="flex flex-col space-y-2">
                <button className="flex items-center space-x-2 text-base text-gray-800 hover:text-orange-500 transition-colors w-full p-2 rounded-lg text-left">
                    <Plus className="w-5 h-5" />
                    <span>Create</span>
                </button>
                <button className="flex items-center space-x-2 text-base text-gray-800 hover:text-orange-500 transition-colors w-full p-2 rounded-lg text-left">
                    <Calendar className="w-5 h-5" />
                    <span>Events</span>
                </button>
                <button className="flex items-center space-x-2 text-base text-gray-800 hover:text-orange-500 transition-colors w-full p-2 rounded-lg text-left">
                    <BookOpen className="w-5 h-5" />
                    <span>Bookings</span>
                </button>
                
                {/* Account/User Link in Mobile Menu */}
                <div className="border-t border-gray-100 my-2"></div>
                <button className="flex items-center space-x-2 text-base text-gray-800 hover:text-orange-500 transition-colors w-full p-2 rounded-lg text-left">
                    <User className="w-5 h-5" />
                    <span>Account</span>
                </button>
            </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;